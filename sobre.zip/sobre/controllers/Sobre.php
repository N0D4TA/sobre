<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Sobre extends MY_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('SobreModel', 'model');
        $this->menu_itens = $this->model->get_menu_itens();
    }

    /**
     * Página inicial do módulo; exibe sua funcionalidade principal. Além desta, um
     * módulo pode ter outras páginas, de acordo com sua finalidade. O importante é
     * lembrar que um módulo deve estar focado em fazer, bem feito e de forma flexível, 
     * apenas uma tarefa.
     */
    public function index(){
        $this->load->model('SobreModel', 'sobre');
        $html = $this->sobre->get_sobre();
        $this->show($html);
    }

    /**
     * Página de configuração do conteúdo exibido nas páginas de funcionalidades do módulo
     */
    public function edit(){
        $this->load->model('SobreModel', 'sobre');
        $this->sobre->get_form();
        $html = $this->load->view('edit', null, true);
        $this->show($html);
    }

}