<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'libraries/util/CI_Object.php';

class Conector extends CI_Object{

   function __construct(){
      parent::__construct();
   }

   public function get_data(array $data){
      $this->db->insert('sobre', $data);
      $id = $this->db->insert_id();
      $rs = $this->db->get_where('sobre', array('id' => $id));
      return $rs->row();
   }

   public function get_id(){
        $res = array();
        $res = $this->db->query('SELECT * FROM sobre WHERE id = (SELECT MAX(id) FROM sobre)');
        foreach($res->result_array() as $res); 
        return $res;
   }
}