<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'libraries/builder/TableBuilder.php';

class SobreTableBuilder extends TableBuilder{

    public function __construct(){
        parent::__construct('sobre');
    }

    function get_fields(){
        $fields['nomeEmpresa'] = array('type' => 'VARCHAR', 'constraint' =>  100);
        $fields['ano'] = array('type' => 'VARCHAR', 'constraint' =>  4);
        $fields['cidade'] = array('type' => 'VARCHAR', 'constraint' =>  50);
        $fields['nomeFundador'] = array('type' => 'VARCHAR', 'constraint' =>  50);
        $fields['missao'] = array('type' => 'VARCHAR', 'constraint' =>  500);
        $fields['numColab'] = array('type' => 'INT');

        return $fields;
    }

    function get_data(){
        $data[] = array(
            'nomeEmpresa' => 'Empresa', 
            'ano' => '2018', 
            'cidade' => 'Cidade',
            'nomeFundador' => 'Nome do Fundador',
            'missao' => 'Uma Missão para empresa, é o porque da sua existência, o objetivo dela',
            'numColab' => 1
        );

        return $data;
    }

}