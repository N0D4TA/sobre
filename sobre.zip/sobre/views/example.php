<div class="card">
    <div class="card-body">
        <h2 class="card-title">Como usar</h2>
            <p class="card-text pr-5 pt-5 pl-5 pb-5 mr-5 mt-5 ml-5 mb-5" style="font-size: 1.5em;">
                Pra começar você deve instalar o modulo, você consegue fazer isso clicando no ícone Install na barra de navegação ou pelo caminho "localhost/mod/sobre/run/install".
                <br><br>
                Tendo concluído essa etapa você pode ir para Config, que altera as opções visuais do módulo, esse tem sua própria explicação na página, ou ir para Editar, que lhe permite
                personalizar a página "Sobre nós" com dados da sua empresa.
                <br><br>
                Tendo feito ambas as alterações você pode visualiza-las na página Início.
            </p>
    </div>
</div>