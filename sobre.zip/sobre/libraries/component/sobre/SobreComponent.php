<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SobreComponent{

    private $data;
    private $text_size;
    private $text_font;
    private $center;
    private $style;

    public function __construct(SobreData $data){
        $this->data = $data;
        $this->center = $data->center ? 'text-center' : 'text-justify';
        $this->text_size = $data->text_size == 2 ? '250%' : ($data->text_size == 1 ? '200%' : '150%');
        $this->text_font = $data->text_font == 4 ? 'Patrick Hand' : ($data->text_font == 3 ? 'Courgette' : ($data->text_font == 2 ? 'Righteous' : ($data->text_font == 1 ? 'Concert One' : '')));
        $this->style = $data->style == 3 ? 'background: linear-gradient(to bottom right, MidnightBlue, MediumSpringGreen);' : 
                      ($data->style == 2 ? 'background-image:url("http://paperlief.com/images/cool-skyscrapers-wallpaper-1.jpg");background-size: 100% 100%;' : 
                      ($data->style == 1 ? 'background-image:url("https://img00.deviantart.net/4bb0/i/2017/235/e/e/the_kustom_shop___beautiful_nature_background_by_thekustomshop-dbl19es.jpg");background-size: 100% 100%;' : ''));
    }
/* 
        O configuravel "style" foi atribuido ao body aqui apenas para ser visualizado, a ideia final seria que ele ficasse numa div com width em 100%, num layer estático abaixo
    da div com o "Sobre Nós", mas não consigo fazer isso com o tempo curto, minhas desculpas.
*/
    public function getHTML(){
        return '<div>
                    <style>
                        body{
                            '.$this->style.'
                        }
                    </style>
                        <div class="'.$this->center.'" style="background:white; background-size: 100%; font-family: \''.$this->text_font.'\', cursive;font-size:'.$this->text_size.';">
                            <h1 class="pr-5 pl-5 pt-4">Sobre nós</h1>
                                <hr><br>
                            <p class="pr-5 pl-5 pb-4"> A empresa '.$this->data->nomeEmpresa.' foi fundada, por '.$this->data->nomeFundador.', na cidade de '.$this->data->cidade.' 
                            no ano de '.$this->data->ano.', e sua principal missão é '.$this->data->missao.'. Atualmente contando com '.$this->data->numColab.' colaboradores.
                        </div>
                </div>';
    }

}
