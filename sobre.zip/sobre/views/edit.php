<div class="container">
   <div class="row justify-content-center">
      <form class="col-md-5 mt-5" method="post">
         <p class="h4 text-center mb-5">Altere os dados da página "Sobre nós"</p>


         <div class="md-form">
            <i class="fa fa-suitcase prefix grey-text"></i>
            <input type="text" id="nomeEmpresa" name="nomeEmpresa" class="form-control" required>
            <label for="nomeEmpresa">Nome da Empresa</label>
         </div>

         
         <div class="md-form">
            <i class="fa fa-user prefix grey-text"></i>
            <input type="text" id="nomeFundador" name="nomeFundador" class="form-control" required>
            <label for="nomeFundador">Nome do(a) Fundador(a)</label>
         </div>

        
         <div class="md-form">
            <i class="fa fa-building prefix grey-text"></i>
            <input type="text" id="cidade" name="cidade" class="form-control" required>
            <label for="cidade">Cidade</label>
         </div>

         <div class="md-form">
            <i class="fa fa-calendar prefix grey-text"></i>
            <input type="number" min="1800" max="2018" id="ano" name="ano" class="form-control" required>
            <label for="ano">Ano</label>
         </div>

        
         <div class="md-form">
            <i class="fa fa-trophy prefix grey-text"></i>
            <input type="text" id="missao" name="missao" class="form-control" required>
            <label for="missao">Missão</label>
         </div>

        
         <div class="md-form">
            <i class="fa fa-user-circle-o prefix grey-text"></i>
            <input type="number" min="1" id="numColab" name="numColab" class="form-control" required>
            <label for="numColab">Número de Colaboradores</label>
         </div>

         <div class="text-center mt-4">
            <button class="btn btn-danger" type="submit">Enviar</button>
         </div>
      </form>
   </div>
</div>