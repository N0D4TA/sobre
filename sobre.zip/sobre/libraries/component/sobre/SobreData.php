<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'libraries/util/CI_Object.php';


class SobreData extends CI_Object{

    public function __construct($id){
        parent::__construct();
        $this->load_data($id);
    }

    private function load_data($id){
        $rs = $this->db->get_where('sobre', array('id' => $id));

        foreach ($rs->row() as $key => $value) {
            $this->$key = $value;

            $this->{'center'} = $this->modconfig->mod_sobre_center;
            $this->{'text_font'} = $this->modconfig->mod_sobre_text_font;
            $this->{'style'} = $this->modconfig->mod_sobre_style;
            $this->{'text_size'} = $this->modconfig->mod_sobre_text_size;
        }
    }
}