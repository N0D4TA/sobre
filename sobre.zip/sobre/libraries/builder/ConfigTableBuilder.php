<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'libraries/builder/ConfigBuilder.php';

class ConfigTableBuilder extends ConfigBuilder{

    function __construct(){
        parent::__construct('sobre');
    }

    function get_data(){
        // parâmetros básicos de configuração
        $base = parent::get_data();

        // parâmetros específicos de configuração
        $data = array(
            array(
                'nome' => $this->prefix.'center', 
                'valor' => true,
                'descricao' => 'Indica so o texto da página "Sobre nós" será alinhado no centro : 1 ou justificado : 0',
                'admin_only' => 0
            ),
            array(
                'nome' => $this->prefix.'text_font', 
                'valor' => 0,
                'descricao' => 'Indica se o texto recebe a fonte Patrick Hand : 4, Courgette : 3, Righteous : 2, Concert One : 1 ou nenhuma : 0.',
                'admin_only' => 0
            ),
            array(
                'nome' => $this->prefix.'text_size', 
                'valor' => 0,
                'descricao' => 'Indica o tamanho da fonte, 250% : 2, 200% : 1, 150% : 0.',
                'admin_only' => 0
            ),
            array(
                'nome' => $this->prefix.'style', 
                'valor' => 0,
                'descricao' => 'Indica o estilo da página "Sobre nós", recebe 3º estilo : 3, 2º estilo : 2, 1º estilo: 1 ou nenhum : 0.',
                'admin_only' => 0
            )
        );
        
        return array_merge($base, $data);
    }
}
