<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once APPPATH.'modules/sobre/libraries/component/sobre/SobreComponent.php';
include_once APPPATH.'modules/sobre/libraries/component/sobre/SobreData.php';
include_once APPPATH.'modules/sobre/libraries/Conector.php';


class SobreModel extends MY_Model{

    public function __construct(){
        $this->conector = new Conector();
    }

    public function get_sobre(){
        $id = $this->conector->get_id();
        $data = new SobreData($id['id']);
        $sn = new SobreComponent($data);
        return $sn->getHTML();
    }    

    public function get_form(){
        if(sizeof($_POST) == 0) return ;
        
        $data = array(
            'nomeEmpresa' => $this->input->post('nomeEmpresa'),
            'nomeFundador' => $this->input->post('nomeFundador'),
            'cidade' => $this->input->post('cidade'),
            'ano' => $this->input->post('ano'),
            'missao' => $this->input->post('missao'),
            'numColab' => $this->input->post('numColab')
        );
        $this->conector->get_data($data);
    }
}
